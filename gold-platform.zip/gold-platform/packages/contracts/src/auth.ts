import { z } from 'zod';

export const emailSchema = z.string().trim().toLowerCase().email().max(254);
export const passwordSchema = z.string().min(12, 'Use at least 12 characters').max(128);

export const registerSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  displayName: z.string().trim().min(1).max(80),
});

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1).max(128),
});

export const refreshSchema = z.object({
  refreshToken: z.string().min(20).max(256),
});

export const updateProfileSchema = z
  .object({
    displayName: z.string().trim().min(1).max(80),
    experienceLevel: z.enum(['beginner', 'intermediate', 'professional']),
    timezone: z.string().trim().min(1).max(64),
    locale: z.string().trim().min(2).max(16),
    theme: z.enum(['light', 'dark', 'system']),
    educationalMode: z.boolean(),
    ictOverlaysEnabled: z.boolean(),
  })
  .partial()
  .strict();

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type RefreshInput = z.infer<typeof refreshSchema>;
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  tokenType: 'Bearer';
  expiresIn: number;
}
