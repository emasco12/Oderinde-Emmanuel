export type ErrorCode =
  | 'UNAUTHENTICATED' | 'INVALID_CREDENTIALS' | 'ACCOUNT_LOCKED' | 'ACCOUNT_SUSPENDED'
  | 'FORBIDDEN' | 'VALIDATION_FAILED' | 'NOT_FOUND' | 'CONFLICT' | 'RATE_LIMITED'
  | 'PLAN_LIMIT_REACHED' | 'DATA_UNAVAILABLE' | 'UPSTREAM_TIMEOUT' | 'INTERNAL_ERROR';

export interface ApiError {
  error: { code: ErrorCode; message: string; details?: unknown; request_id: string };
}

export interface ApiSuccess<T> {
  data: T;
  meta: { request_id: string; next_cursor?: string };
}
