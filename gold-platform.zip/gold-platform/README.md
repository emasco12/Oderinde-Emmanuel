# Gold Intelligence Platform

Step 1 of the build: monorepo scaffold plus the **identity module** (register, login, refresh, logout, profile, roles and permissions, audit log).

> Status: this code has **not been installed, compiled, or run yet**. It was written in an environment without network access. Expect to fix small typing or version issues on the first `pnpm install` and `pnpm test`. Dependency versions should be confirmed on first install.

## Layout

- `apps/api`: NestJS API (`/api/v1`)
- `packages/contracts`: shared Zod schemas and types (single source of truth for request validation)
- `docker-compose.yml`: PostgreSQL (with TimescaleDB and pgvector available) and Redis for development
- `.devcontainer`: GitHub Codespaces config, so you can run everything from a phone browser

## Run it

```bash
corepack enable
pnpm install
cp apps/api/.env.example apps/api/.env      # then set JWT_ACCESS_SECRET (openssl rand -base64 48)
docker compose up -d
pnpm --filter @gold/contracts build
pnpm --filter api db:migrate -- --name init
pnpm --filter api db:seed
pnpm --filter api dev
```

API docs (development only): http://localhost:3001/docs
Health: `GET /health/live`, `GET /health/ready`

## Try it

```bash
curl -X POST localhost:3001/api/v1/auth/register -H 'content-type: application/json' \
  -d '{"email":"me@example.com","password":"a-long-passphrase-123","displayName":"Me"}'
curl -X POST localhost:3001/api/v1/auth/login -H 'content-type: application/json' \
  -d '{"email":"me@example.com","password":"a-long-passphrase-123"}'
curl localhost:3001/api/v1/me -H "authorization: Bearer <accessToken>"
```

## Tests

```bash
pnpm test
```

Covers password hashing, login failure and lockout rules, refresh rotation with reuse detection, and duplicate registration.

## Design decisions

- **Modular monolith**: one deployable now, with domain boundaries ready to split later.
- **Refresh token rotation**: tokens are random strings stored only as SHA-256 hashes. Replaying a used token revokes the whole family.
- **Lockout**: 5 failed logins locks the account for 15 minutes. Unknown emails take the same time as wrong passwords.
- **Roles and permissions**: seeded from `prisma/seed.ts`. Routes declare `@RequirePermissions('signals.read')`. Routes are private by default and opened with `@Public()`.
- **Errors**: always `{ error: { code, message, details?, request_id } }`. Successes: `{ data, meta: { request_id } }`.

## Known differences from the schema spec

- `users.email` is stored lowercase by the API instead of using `citext`.
- IDs are UUID v4 for now (Prisma's built-in), not UUIDv7.
- `audit_logs` has no `updated_at` because it is append-only.
- Two-factor columns exist, but enable and verify endpoints come in a later step. Login does not check 2FA yet.
- Email verification and password reset are not built yet.

## Production hardening still to do

- Run the app with a database role that can only `INSERT` and `SELECT` on `audit_logs`.
- Distributed rate limiting (Redis store) once more than one API instance runs.
- Set `TRUST_PROXY=true` only behind Nginx or a load balancer.
