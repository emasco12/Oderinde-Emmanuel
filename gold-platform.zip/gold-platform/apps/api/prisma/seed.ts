import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const PERMISSIONS: Record<string, string> = {
  'market.read': 'View market prices',
  'calendar.read': 'View the economic calendar',
  'news.read': 'View news',
  'analysis.read': 'View AI market analysis',
  'signals.read': 'View signals',
  'heatmap.read': 'View the heat map',
  'reports.generate': 'Generate AI reports',
  'journal.write': 'Use the trading journal',
  'alerts.write': 'Create alerts',
  'api_keys.manage': 'Manage API keys',
  'research.publish': 'Publish research content',
  'moderation.manage': 'Moderate content and feedback',
  'admin.users.read': 'View users',
  'admin.users.write': 'Edit users',
  'admin.system.read': 'View system health',
  'admin.roles.assign': 'Assign administrator roles',
};

const free = ['market.read', 'calendar.read', 'news.read', 'analysis.read', 'alerts.write', 'journal.write'];
const premium = [...free, 'signals.read', 'heatmap.read', 'reports.generate'];

const ROLES: Record<string, { name: string; permissions: string[] }> = {
  guest: { name: 'Guest', permissions: ['market.read'] },
  free: { name: 'Free user', permissions: free },
  premium: { name: 'Premium user', permissions: premium },
  professional: { name: 'Professional user', permissions: premium },
  enterprise: { name: 'Enterprise user', permissions: [...premium, 'api_keys.manage'] },
  analyst: { name: 'Analyst', permissions: [...premium, 'research.publish'] },
  moderator: { name: 'Moderator', permissions: [...free, 'moderation.manage'] },
  admin: {
    name: 'Administrator',
    permissions: [...premium, 'moderation.manage', 'admin.users.read', 'admin.users.write', 'admin.system.read'],
  },
  super_admin: { name: 'Super administrator', permissions: Object.keys(PERMISSIONS) },
};

async function main(): Promise<void> {
  for (const [key, description] of Object.entries(PERMISSIONS)) {
    await prisma.permission.upsert({ where: { key }, update: { description }, create: { key, description } });
  }
  for (const [key, def] of Object.entries(ROLES)) {
    const role = await prisma.role.upsert({ where: { key }, update: { name: def.name }, create: { key, name: def.name } });
    for (const permKey of def.permissions) {
      const permission = await prisma.permission.findUniqueOrThrow({ where: { key: permKey } });
      await prisma.rolePermission.upsert({
        where: { roleId_permissionId: { roleId: role.id, permissionId: permission.id } },
        update: {},
        create: { roleId: role.id, permissionId: permission.id },
      });
    }
  }
  console.log('Seeded roles and permissions.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
