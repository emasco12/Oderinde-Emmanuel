import { AuthService, LOCK_DURATION_MS, MAX_FAILED_LOGINS } from './auth.service';

const ctx = { ip: '127.0.0.1', userAgent: 'jest', requestId: 'req-12345678' };
const login = { email: 'trader@example.com', password: 'correct horse battery staple' };

function makeUser(overrides: Record<string, unknown> = {}) {
  return {
    id: 'user-1',
    email: login.email,
    passwordHash: 'hash',
    status: 'active',
    failedLoginCount: 0,
    lockedUntil: null,
    deletedAt: null,
    roles: [{ expiresAt: null, role: { key: 'free' } }],
    ...overrides,
  };
}

function setup() {
  const prisma: any = {
    user: { findFirst: jest.fn(), update: jest.fn() },
    refreshToken: { create: jest.fn(), findUnique: jest.fn(), updateMany: jest.fn() },
    role: { findUnique: jest.fn() },
  };
  prisma.$transaction = jest.fn((fn: (tx: unknown) => unknown) => fn(prisma));
  const passwords = { hash: jest.fn(), verify: jest.fn(), burn: jest.fn() };
  const tokens = {
    signAccess: jest.fn().mockResolvedValue('access.jwt'),
    newRefreshToken: jest.fn().mockReturnValue({ token: 'refresh-token-value-0000000000', hash: 'hashed' }),
    hashToken: jest.fn().mockReturnValue('hashed'),
    accessTtlSeconds: 900,
    refreshTtlMs: 1000,
  };
  const audit = { record: jest.fn() };
  const service = new AuthService(prisma, passwords as any, tokens as any, audit as any);
  return { service, prisma, passwords, tokens, audit };
}

describe('AuthService.login', () => {
  it('rejects an unknown email with the same error and still burns hashing time', async () => {
    const { service, prisma, passwords } = setup();
    prisma.user.findFirst.mockResolvedValue(null);
    await expect(service.login(login, ctx)).rejects.toMatchObject({ code: 'INVALID_CREDENTIALS', status: 401 });
    expect(passwords.burn).toHaveBeenCalledWith(login.password);
  });

  it('counts a failed attempt without locking before the limit', async () => {
    const { service, prisma, passwords } = setup();
    prisma.user.findFirst.mockResolvedValue(makeUser({ failedLoginCount: 1 }));
    passwords.verify.mockResolvedValue(false);
    await expect(service.login(login, ctx)).rejects.toMatchObject({ code: 'INVALID_CREDENTIALS' });
    expect(prisma.user.update).toHaveBeenCalledWith({ where: { id: 'user-1' }, data: { failedLoginCount: 2 } });
  });

  it('locks the account on the final allowed failure', async () => {
    const { service, prisma, passwords } = setup();
    prisma.user.findFirst.mockResolvedValue(makeUser({ failedLoginCount: MAX_FAILED_LOGINS - 1 }));
    passwords.verify.mockResolvedValue(false);
    const before = Date.now();
    await expect(service.login(login, ctx)).rejects.toMatchObject({ code: 'INVALID_CREDENTIALS' });
    const data = prisma.user.update.mock.calls[0][0].data;
    expect(data.failedLoginCount).toBe(0);
    expect(data.lockedUntil.getTime()).toBeGreaterThanOrEqual(before + LOCK_DURATION_MS);
  });

  it('refuses a locked account without checking the password', async () => {
    const { service, prisma, passwords } = setup();
    prisma.user.findFirst.mockResolvedValue(makeUser({ lockedUntil: new Date(Date.now() + 60_000) }));
    await expect(service.login(login, ctx)).rejects.toMatchObject({ code: 'ACCOUNT_LOCKED', status: 423 });
    expect(passwords.verify).not.toHaveBeenCalled();
  });

  it('refuses a suspended account only after the password is correct', async () => {
    const { service, prisma, passwords } = setup();
    prisma.user.findFirst.mockResolvedValue(makeUser({ status: 'suspended' }));
    passwords.verify.mockResolvedValue(true);
    await expect(service.login(login, ctx)).rejects.toMatchObject({ code: 'ACCOUNT_SUSPENDED' });
  });

  it('issues tokens and resets the failure counter on success', async () => {
    const { service, prisma, passwords, tokens } = setup();
    prisma.user.findFirst.mockResolvedValue(makeUser({ failedLoginCount: 3 }));
    passwords.verify.mockResolvedValue(true);
    const result = await service.login(login, ctx);
    expect(result).toEqual({
      accessToken: 'access.jwt',
      refreshToken: 'refresh-token-value-0000000000',
      tokenType: 'Bearer',
      expiresIn: 900,
    });
    expect(tokens.signAccess).toHaveBeenCalledWith({ sub: 'user-1', roles: ['free'] });
    expect(prisma.user.update.mock.calls[0][0].data).toMatchObject({ failedLoginCount: 0, lockedUntil: null });
    expect(prisma.refreshToken.create).toHaveBeenCalled();
  });
});

describe('AuthService.refresh', () => {
  it('rejects an unknown refresh token', async () => {
    const { service, prisma } = setup();
    prisma.refreshToken.findUnique.mockResolvedValue(null);
    await expect(service.refresh({ refreshToken: 'x'.repeat(30) }, ctx)).rejects.toMatchObject({ code: 'UNAUTHENTICATED' });
  });

  it('revokes the whole token family when a used token is replayed', async () => {
    const { service, prisma, audit } = setup();
    prisma.refreshToken.findUnique.mockResolvedValue({
      id: 't1', userId: 'user-1', familyId: 'fam-1', revokedAt: new Date(), expiresAt: new Date(Date.now() + 1000), user: makeUser(),
    });
    await expect(service.refresh({ refreshToken: 'x'.repeat(30) }, ctx)).rejects.toMatchObject({ code: 'UNAUTHENTICATED' });
    expect(prisma.refreshToken.updateMany).toHaveBeenCalledWith({
      where: { familyId: 'fam-1', revokedAt: null },
      data: { revokedAt: expect.any(Date) },
    });
    expect(audit.record).toHaveBeenCalledWith(expect.objectContaining({ action: 'auth.refresh_reuse_detected' }));
  });

  it('rotates a valid token within the same family', async () => {
    const { service, prisma } = setup();
    prisma.refreshToken.findUnique.mockResolvedValue({
      id: 't1', userId: 'user-1', familyId: 'fam-1', revokedAt: null, expiresAt: new Date(Date.now() + 60_000), user: makeUser(),
    });
    prisma.refreshToken.updateMany.mockResolvedValue({ count: 1 });
    const result = await service.refresh({ refreshToken: 'x'.repeat(30) }, ctx);
    expect(result.accessToken).toBe('access.jwt');
    expect(prisma.refreshToken.create.mock.calls[0][0].data.familyId).toBe('fam-1');
  });
});

describe('AuthService.register', () => {
  it('maps a duplicate email to a CONFLICT error', async () => {
    const { service, prisma, passwords } = setup();
    passwords.hash.mockResolvedValue('hash');
    prisma.$transaction.mockRejectedValue(Object.assign(new Error('unique'), { code: 'P2002' }));
    await expect(
      service.register({ email: login.email, password: login.password, displayName: 'T' }, ctx),
    ).rejects.toMatchObject({ code: 'CONFLICT', status: 409 });
  });
});
