import { Injectable } from '@nestjs/common';
import type { UpdateProfileInput } from '@gold/contracts';
import { AppError } from '../common/app-error';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  async getMe(userId: string) {
    const user = await this.prisma.user.findFirst({
      where: { id: userId, deletedAt: null },
      include: { profile: true, roles: { include: { role: true } } },
    });
    if (!user) throw new AppError('NOT_FOUND', 404, 'Account not found.');
    const now = new Date();
    return {
      id: user.id,
      email: user.email,
      emailVerified: user.emailVerifiedAt !== null,
      twoFactorEnabled: user.twoFactorEnabled,
      roles: user.roles.filter((ur) => !ur.expiresAt || ur.expiresAt > now).map((ur) => ur.role.key),
      profile: user.profile,
    };
  }

  async updateProfile(userId: string, input: UpdateProfileInput) {
    await this.prisma.profile.update({ where: { userId }, data: input });
    return this.getMe(userId);
  }
}
