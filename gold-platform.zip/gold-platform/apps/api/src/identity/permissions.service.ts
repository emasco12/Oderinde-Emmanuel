import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

const CACHE_TTL_MS = 60_000;

/** Resolves role keys to permission keys, with a short in-memory cache. */
@Injectable()
export class PermissionsService {
  private readonly cache = new Map<string, { expires: number; permissions: Set<string> }>();

  constructor(private readonly prisma: PrismaService) {}

  async permissionsFor(roles: string[]): Promise<Set<string>> {
    const cacheKey = [...roles].sort().join(',');
    const hit = this.cache.get(cacheKey);
    if (hit && hit.expires > Date.now()) return hit.permissions;

    const rows = await this.prisma.rolePermission.findMany({
      where: { role: { key: { in: roles } } },
      select: { permission: { select: { key: true } } },
    });
    const permissions = new Set(rows.map((r) => r.permission.key));
    this.cache.set(cacheKey, { expires: Date.now() + CACHE_TTL_MS, permissions });
    return permissions;
  }
}
