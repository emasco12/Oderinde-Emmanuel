import { Injectable } from '@nestjs/common';
import * as argon2 from 'argon2';

@Injectable()
export class PasswordService {
  private decoyHash?: Promise<string>;

  /** Hashes with argon2id (library defaults are suitable for interactive logins). */
  hash(password: string): Promise<string> {
    return argon2.hash(password, { type: argon2.argon2id });
  }

  async verify(hash: string, password: string): Promise<boolean> {
    try {
      return await argon2.verify(hash, password);
    } catch {
      return false;
    }
  }

  /** Spends the same time as a real check, so unknown emails can't be told apart by response time. */
  async burn(password: string): Promise<void> {
    this.decoyHash ??= this.hash('decoy-password-for-timing-only');
    await this.verify(await this.decoyHash, password);
  }
}
