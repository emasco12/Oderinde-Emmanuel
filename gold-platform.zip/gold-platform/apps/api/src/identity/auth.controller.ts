import { Body, Controller, HttpCode, Post, Req } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import {
  LoginInput, RefreshInput, RegisterInput,
  loginSchema, refreshSchema, registerSchema,
} from '@gold/contracts';
import { ZodValidationPipe } from '../common/zod-validation.pipe';
import { AppRequest, contextOf } from '../common/request';
import { AuthService } from './auth.service';
import { Public } from './decorators';

const STRICT = { default: { ttl: 60_000, limit: 5 } };

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Public()
  @Throttle(STRICT)
  @Post('register')
  register(@Body(new ZodValidationPipe(registerSchema)) body: RegisterInput, @Req() req: AppRequest) {
    return this.auth.register(body, contextOf(req));
  }

  @Public()
  @Throttle(STRICT)
  @HttpCode(200)
  @Post('login')
  login(@Body(new ZodValidationPipe(loginSchema)) body: LoginInput, @Req() req: AppRequest) {
    return this.auth.login(body, contextOf(req));
  }

  @Public()
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  @HttpCode(200)
  @Post('refresh')
  refresh(@Body(new ZodValidationPipe(refreshSchema)) body: RefreshInput, @Req() req: AppRequest) {
    return this.auth.refresh(body, contextOf(req));
  }

  @Public()
  @HttpCode(200)
  @Post('logout')
  async logout(@Body(new ZodValidationPipe(refreshSchema)) body: RefreshInput, @Req() req: AppRequest) {
    await this.auth.logout(body, contextOf(req));
    return null;
  }
}
