import { Body, Controller, Get, Patch } from '@nestjs/common';
import { UpdateProfileInput, updateProfileSchema } from '@gold/contracts';
import type { AuthUser } from '../common/request';
import { ZodValidationPipe } from '../common/zod-validation.pipe';
import { CurrentUser } from './decorators';
import { UsersService } from './users.service';

@Controller('me')
export class UsersController {
  constructor(private readonly users: UsersService) {}

  @Get()
  me(@CurrentUser() user: AuthUser) {
    return this.users.getMe(user.id);
  }

  @Patch()
  update(@CurrentUser() user: AuthUser, @Body(new ZodValidationPipe(updateProfileSchema)) body: UpdateProfileInput) {
    return this.users.updateProfile(user.id, body);
  }
}
