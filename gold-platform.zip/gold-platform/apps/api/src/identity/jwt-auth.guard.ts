import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AppError } from '../common/app-error';
import type { AppRequest } from '../common/request';
import { IS_PUBLIC } from './decorators';
import { TokenService } from './token.service';

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly tokens: TokenService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC, [context.getHandler(), context.getClass()]);
    if (isPublic) return true;

    const req = context.switchToHttp().getRequest<AppRequest>();
    const header = req.headers.authorization;
    const token = header?.startsWith('Bearer ') ? header.slice(7) : undefined;
    if (!token) throw new AppError('UNAUTHENTICATED', 401, 'Sign in to continue.');

    try {
      const payload = await this.tokens.verifyAccess(token);
      if (!payload.sub || !Array.isArray(payload.roles)) throw new Error('malformed payload');
      req.user = { id: payload.sub, roles: payload.roles };
      return true;
    } catch {
      throw new AppError('UNAUTHENTICATED', 401, 'Your session has expired. Please sign in again.');
    }
  }
}
