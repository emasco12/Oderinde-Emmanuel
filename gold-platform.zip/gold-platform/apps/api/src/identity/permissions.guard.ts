import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AppError } from '../common/app-error';
import type { AppRequest } from '../common/request';
import { PERMISSIONS_KEY } from './decorators';
import { PermissionsService } from './permissions.service';

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly permissions: PermissionsService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const required = this.reflector.getAllAndOverride<string[] | undefined>(PERMISSIONS_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!required || required.length === 0) return true;

    const user = context.switchToHttp().getRequest<AppRequest>().user;
    if (!user) throw new AppError('UNAUTHENTICATED', 401, 'Sign in to continue.');

    const granted = await this.permissions.permissionsFor(user.roles);
    if (!required.every((p) => granted.has(p))) {
      throw new AppError('FORBIDDEN', 403, 'Your plan or role does not include this feature.');
    }
    return true;
  }
}
