import { ExecutionContext, SetMetadata, createParamDecorator } from '@nestjs/common';
import type { AppRequest, AuthUser } from '../common/request';

export const IS_PUBLIC = 'isPublic';
export const PERMISSIONS_KEY = 'permissions';

/** Marks a route as open to unauthenticated callers. Everything else requires a valid access token. */
export const Public = () => SetMetadata(IS_PUBLIC, true);

/** Requires the caller's roles to grant ALL of the listed permissions. */
export const RequirePermissions = (...permissions: string[]) => SetMetadata(PERMISSIONS_KEY, permissions);

export const CurrentUser = createParamDecorator((_data: unknown, ctx: ExecutionContext): AuthUser => {
  const req = ctx.switchToHttp().getRequest<AppRequest>();
  return req.user as AuthUser;
});
