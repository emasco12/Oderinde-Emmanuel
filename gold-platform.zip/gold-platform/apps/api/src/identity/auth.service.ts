import { randomUUID } from 'node:crypto';
import { Injectable } from '@nestjs/common';
import type { Prisma } from '@prisma/client';
import type { LoginInput, RefreshInput, RegisterInput, TokenPair } from '@gold/contracts';
import { AuditService } from '../audit/audit.service';
import { AppError } from '../common/app-error';
import type { RequestContext } from '../common/request';
import { PrismaService } from '../prisma/prisma.service';
import { PasswordService } from './password.service';
import { TokenService } from './token.service';

export const MAX_FAILED_LOGINS = 5;
export const LOCK_DURATION_MS = 15 * 60 * 1000;

type Db = PrismaService | Prisma.TransactionClient;

const INVALID_CREDENTIALS = () => new AppError('INVALID_CREDENTIALS', 401, 'Email or password is incorrect.');
const INVALID_REFRESH = () => new AppError('UNAUTHENTICATED', 401, 'Your session has expired. Please sign in again.');

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly passwords: PasswordService,
    private readonly tokens: TokenService,
    private readonly audit: AuditService,
  ) {}

  async register(input: RegisterInput, ctx: RequestContext): Promise<{ id: string; email: string; displayName: string }> {
    const passwordHash = await this.passwords.hash(input.password);
    try {
      const user = await this.prisma.$transaction(async (tx) => {
        const role = await tx.role.findUnique({ where: { key: 'free' } });
        if (!role) throw new Error('Role "free" is missing. Run the database seed.');
        return tx.user.create({
          data: {
            email: input.email,
            passwordHash,
            profile: { create: { displayName: input.displayName } },
            roles: { create: { roleId: role.id } },
          },
        });
      });
      await this.audit.record({ actorUserId: user.id, action: 'user.registered', entityType: 'user', entityId: user.id, ip: ctx.ip, requestId: ctx.requestId });
      return { id: user.id, email: user.email, displayName: input.displayName };
    } catch (err) {
      if (typeof err === 'object' && err !== null && (err as { code?: string }).code === 'P2002') {
        throw new AppError('CONFLICT', 409, 'An account with this email already exists.');
      }
      throw err;
    }
  }

  async login(input: LoginInput, ctx: RequestContext): Promise<TokenPair> {
    const user = await this.prisma.user.findFirst({
      where: { email: input.email, deletedAt: null },
      include: { roles: { include: { role: true } } },
    });

    if (!user) {
      await this.passwords.burn(input.password);
      await this.audit.record({ action: 'auth.login_failed', entityType: 'user', ip: ctx.ip, requestId: ctx.requestId });
      throw INVALID_CREDENTIALS();
    }

    const now = new Date();
    if (user.lockedUntil && user.lockedUntil > now) {
      throw new AppError('ACCOUNT_LOCKED', 423, 'Too many failed sign-in attempts. Try again in a few minutes.');
    }

    const valid = await this.passwords.verify(user.passwordHash, input.password);
    if (!valid) {
      const attempts = user.failedLoginCount + 1;
      const shouldLock = attempts >= MAX_FAILED_LOGINS;
      await this.prisma.user.update({
        where: { id: user.id },
        data: shouldLock
          ? { failedLoginCount: 0, lockedUntil: new Date(now.getTime() + LOCK_DURATION_MS) }
          : { failedLoginCount: attempts },
      });
      await this.audit.record({
        actorUserId: user.id,
        action: shouldLock ? 'auth.account_locked' : 'auth.login_failed',
        entityType: 'user',
        entityId: user.id,
        ip: ctx.ip,
        requestId: ctx.requestId,
      });
      throw INVALID_CREDENTIALS();
    }

    if (user.status === 'suspended') {
      throw new AppError('ACCOUNT_SUSPENDED', 403, 'This account has been suspended. Contact support.');
    }

    await this.prisma.user.update({
      where: { id: user.id },
      data: { failedLoginCount: 0, lockedUntil: null, lastLoginAt: now },
    });
    await this.audit.record({ actorUserId: user.id, action: 'auth.login', entityType: 'user', entityId: user.id, ip: ctx.ip, requestId: ctx.requestId });

    const roles = user.roles
      .filter((ur) => !ur.expiresAt || ur.expiresAt > now)
      .map((ur) => ur.role.key);
    return this.issueTokens(this.prisma, user.id, roles, randomUUID(), ctx);
  }

  /** Rotates the refresh token. Presenting an already-used token revokes the whole token family. */
  async refresh(input: RefreshInput, ctx: RequestContext): Promise<TokenPair> {
    const hash = this.tokens.hashToken(input.refreshToken);
    const existing = await this.prisma.refreshToken.findUnique({
      where: { tokenHash: hash },
      include: { user: { include: { roles: { include: { role: true } } } } },
    });
    if (!existing) throw INVALID_REFRESH();

    const now = new Date();
    if (existing.revokedAt) {
      await this.prisma.refreshToken.updateMany({
        where: { familyId: existing.familyId, revokedAt: null },
        data: { revokedAt: now },
      });
      await this.audit.record({
        actorUserId: existing.userId,
        action: 'auth.refresh_reuse_detected',
        entityType: 'user',
        entityId: existing.userId,
        ip: ctx.ip,
        requestId: ctx.requestId,
      });
      throw INVALID_REFRESH();
    }

    const { user } = existing;
    if (existing.expiresAt <= now || user.deletedAt || user.status !== 'active') throw INVALID_REFRESH();

    const roles = user.roles.filter((ur) => !ur.expiresAt || ur.expiresAt > now).map((ur) => ur.role.key);
    return this.prisma.$transaction(async (tx) => {
      const revoked = await tx.refreshToken.updateMany({
        where: { id: existing.id, revokedAt: null },
        data: { revokedAt: now },
      });
      if (revoked.count === 0) throw INVALID_REFRESH(); // lost a race with another refresh
      return this.issueTokens(tx, user.id, roles, existing.familyId, ctx);
    });
  }

  /** Signs out the device by revoking its token family. Unknown tokens are ignored on purpose. */
  async logout(input: RefreshInput, ctx: RequestContext): Promise<void> {
    const existing = await this.prisma.refreshToken.findUnique({ where: { tokenHash: this.tokens.hashToken(input.refreshToken) } });
    if (!existing) return;
    await this.prisma.refreshToken.updateMany({
      where: { familyId: existing.familyId, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    await this.audit.record({ actorUserId: existing.userId, action: 'auth.logout', entityType: 'user', entityId: existing.userId, ip: ctx.ip, requestId: ctx.requestId });
  }

  private async issueTokens(db: Db, userId: string, roles: string[], familyId: string, ctx: RequestContext): Promise<TokenPair> {
    const accessToken = await this.tokens.signAccess({ sub: userId, roles });
    const { token, hash } = this.tokens.newRefreshToken();
    await db.refreshToken.create({
      data: {
        userId,
        tokenHash: hash,
        familyId,
        expiresAt: new Date(Date.now() + this.tokens.refreshTtlMs),
        ip: ctx.ip,
        userAgent: ctx.userAgent,
      },
    });
    return { accessToken, refreshToken: token, tokenType: 'Bearer', expiresIn: this.tokens.accessTtlSeconds };
  }
}
