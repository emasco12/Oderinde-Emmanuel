import { PasswordService } from './password.service';

describe('PasswordService', () => {
  const service = new PasswordService();

  it('hashes with argon2id and verifies the right password only', async () => {
    const hash = await service.hash('correct horse battery staple');
    expect(hash.startsWith('$argon2id$')).toBe(true);
    expect(hash).not.toContain('correct horse');
    expect(await service.verify(hash, 'correct horse battery staple')).toBe(true);
    expect(await service.verify(hash, 'wrong password entirely')).toBe(false);
  });

  it('returns false instead of throwing for a malformed hash', async () => {
    expect(await service.verify('not-a-hash', 'anything')).toBe(false);
  });
});
