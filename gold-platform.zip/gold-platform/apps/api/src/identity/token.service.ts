import { createHash, randomBytes } from 'node:crypto';
import { Inject, Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ENV, Env } from '../config/env';

export interface AccessPayload {
  sub: string;
  roles: string[];
}

@Injectable()
export class TokenService {
  constructor(
    private readonly jwt: JwtService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  get accessTtlSeconds(): number {
    return this.env.ACCESS_TTL_SECONDS;
  }

  get refreshTtlMs(): number {
    return this.env.REFRESH_TTL_DAYS * 24 * 60 * 60 * 1000;
  }

  signAccess(payload: AccessPayload): Promise<string> {
    return this.jwt.signAsync(payload);
  }

  verifyAccess(token: string): Promise<AccessPayload> {
    return this.jwt.verifyAsync<AccessPayload>(token);
  }

  /** Refresh tokens are opaque random strings; only their SHA-256 hash is ever stored. */
  newRefreshToken(): { token: string; hash: string } {
    const token = randomBytes(48).toString('base64url');
    return { token, hash: this.hashToken(token) };
  }

  hashToken(token: string): string {
    return createHash('sha256').update(token).digest('hex');
  }
}
