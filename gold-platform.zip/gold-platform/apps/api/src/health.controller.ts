import { Controller, Get } from '@nestjs/common';
import { SkipThrottle } from '@nestjs/throttler';
import { AppError } from './common/app-error';
import { Public } from './identity/decorators';
import { PrismaService } from './prisma/prisma.service';

@SkipThrottle()
@Public()
@Controller('health')
export class HealthController {
  constructor(private readonly prisma: PrismaService) {}

  @Get('live')
  live() {
    return { status: 'ok' };
  }

  @Get('ready')
  async ready() {
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      return { status: 'ok', database: 'up' };
    } catch {
      throw new AppError('DATA_UNAVAILABLE', 503, 'The database is not reachable.');
    }
  }
}
