import type { ErrorCode } from '@gold/contracts';

/** An expected, user-facing failure. The message must be safe to show to end users. */
export class AppError extends Error {
  constructor(
    readonly code: ErrorCode,
    readonly status: number,
    message: string,
    readonly details?: unknown,
  ) {
    super(message);
    this.name = 'AppError';
  }
}
