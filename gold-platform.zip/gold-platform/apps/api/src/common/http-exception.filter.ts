import { ArgumentsHost, Catch, ExceptionFilter, HttpException, Logger } from '@nestjs/common';
import type { ErrorCode } from '@gold/contracts';
import type { Response } from 'express';
import { AppError } from './app-error';
import type { AppRequest } from './request';

/** Converts every error into the platform's structured error envelope without leaking internals. */
@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(HttpExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const http = host.switchToHttp();
    const res = http.getResponse<Response>();
    const req = http.getRequest<AppRequest>();

    let status = 500;
    let code: ErrorCode = 'INTERNAL_ERROR';
    let message = 'Something went wrong on our side. Please try again.';
    let details: unknown;

    if (exception instanceof AppError) {
      status = exception.status;
      code = exception.code;
      message = exception.message;
      details = exception.details;
    } else if (exception instanceof HttpException && exception.getStatus() < 500) {
      status = exception.getStatus();
      message = exception.message;
      code =
        status === 401 ? 'UNAUTHENTICATED'
        : status === 403 ? 'FORBIDDEN'
        : status === 404 ? 'NOT_FOUND'
        : status === 429 ? 'RATE_LIMITED'
        : 'VALIDATION_FAILED';
      if (status === 429) message = 'Too many requests. Please wait a moment and try again.';
    } else {
      this.logger.error(
        `Unhandled error (request ${req.requestId})`,
        exception instanceof Error ? exception.stack : String(exception),
      );
    }

    res.status(status).json({ error: { code, message, details, request_id: req.requestId } });
  }
}
