import type { Request } from 'express';

export interface AuthUser {
  id: string;
  roles: string[];
}

export interface AppRequest extends Request {
  requestId: string;
  user?: AuthUser;
}

/** Request metadata passed to services for audit logging and token records. */
export interface RequestContext {
  ip?: string;
  userAgent?: string;
  requestId?: string;
}

export function contextOf(req: AppRequest): RequestContext {
  const ua = req.headers['user-agent'];
  return { ip: req.ip, userAgent: typeof ua === 'string' ? ua.slice(0, 255) : undefined, requestId: req.requestId };
}
