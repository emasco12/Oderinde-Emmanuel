import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable, map } from 'rxjs';
import type { AppRequest } from './request';

/** Wraps every successful response as { data, meta: { request_id } }. */
@Injectable()
export class ResponseInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const req = context.switchToHttp().getRequest<AppRequest>();
    return next.handle().pipe(map((data) => ({ data: data ?? null, meta: { request_id: req.requestId } })));
  }
}
